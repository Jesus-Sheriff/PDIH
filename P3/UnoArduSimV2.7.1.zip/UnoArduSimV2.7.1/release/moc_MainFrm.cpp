/****************************************************************************
** Meta object code from reading C++ file 'MainFrm.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.6.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../QUnoArduSimProject/MainFrm.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainFrm.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.6.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_CMainFrm_t {
    QByteArrayData data[50];
    char stringdata0[817];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CMainFrm_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CMainFrm_t qt_meta_stringdata_CMainFrm = {
    {
QT_MOC_LITERAL(0, 0, 8), // "CMainFrm"
QT_MOC_LITERAL(1, 9, 10), // "OnFileNext"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 10), // "OnFilePrev"
QT_MOC_LITERAL(4, 32, 10), // "OnFileLoad"
QT_MOC_LITERAL(5, 43, 14), // "OnFileEditView"
QT_MOC_LITERAL(6, 58, 10), // "OnFileSave"
QT_MOC_LITERAL(7, 69, 12), // "OnFileSaveAs"
QT_MOC_LITERAL(8, 82, 19), // "GetFileTextEncoding"
QT_MOC_LITERAL(9, 102, 11), // "QTextCodec*"
QT_MOC_LITERAL(10, 114, 6), // "QFile&"
QT_MOC_LITERAL(11, 121, 10), // "qfileCheck"
QT_MOC_LITERAL(12, 132, 10), // "OnFileExit"
QT_MOC_LITERAL(13, 143, 14), // "OnFindFuncNext"
QT_MOC_LITERAL(14, 158, 14), // "OnFindFuncPrev"
QT_MOC_LITERAL(15, 173, 13), // "OnFindSetText"
QT_MOC_LITERAL(16, 187, 14), // "OnFindTextNext"
QT_MOC_LITERAL(17, 202, 14), // "OnFindTextPrev"
QT_MOC_LITERAL(18, 217, 16), // "OnFindTextEdited"
QT_MOC_LITERAL(19, 234, 11), // "strgNewText"
QT_MOC_LITERAL(20, 246, 17), // "SetStepParameters"
QT_MOC_LITERAL(21, 264, 17), // "OnExecuteStepInto"
QT_MOC_LITERAL(22, 282, 18), // "OnExecuteStepOutOf"
QT_MOC_LITERAL(23, 301, 17), // "OnExecuteStepOver"
QT_MOC_LITERAL(24, 319, 12), // "OnExecuteRun"
QT_MOC_LITERAL(25, 332, 14), // "OnExecuteRunTo"
QT_MOC_LITERAL(26, 347, 16), // "OnExecuteRunTill"
QT_MOC_LITERAL(27, 364, 13), // "OnExecuteHalt"
QT_MOC_LITERAL(28, 378, 19), // "OnExecuteSlowMotion"
QT_MOC_LITERAL(29, 398, 16), // "OnExecuteAnimate"
QT_MOC_LITERAL(30, 415, 14), // "OnExecuteReset"
QT_MOC_LITERAL(31, 430, 25), // "OnOptionsStepOverSpecials"
QT_MOC_LITERAL(32, 456, 23), // "OnOptionsModelRegisters"
QT_MOC_LITERAL(33, 480, 29), // "OnOptionsErrorOnUninitialized"
QT_MOC_LITERAL(34, 510, 23), // "OnOptionsAddedLoopDelay"
QT_MOC_LITERAL(35, 534, 25), // "OnOptionsNestedInterrupts"
QT_MOC_LITERAL(36, 560, 13), // "OnConfigPrefs"
QT_MOC_LITERAL(37, 574, 14), // "OnConfigIODevs"
QT_MOC_LITERAL(38, 589, 22), // "OnWindowsSerialMonitor"
QT_MOC_LITERAL(39, 612, 19), // "OnWindowsRestoreAll"
QT_MOC_LITERAL(40, 632, 21), // "OnWindowsDigitalWaves"
QT_MOC_LITERAL(41, 654, 19), // "OnWindowsAnalogWave"
QT_MOC_LITERAL(42, 674, 29), // "OnVarUpdatesAllowAutoCollapse"
QT_MOC_LITERAL(43, 704, 19), // "OnVarUpdatesMinimal"
QT_MOC_LITERAL(44, 724, 28), // "OnVarUpdatesHighlightChanges"
QT_MOC_LITERAL(45, 753, 10), // "OnHelpFull"
QT_MOC_LITERAL(46, 764, 11), // "OnHelpQuick"
QT_MOC_LITERAL(47, 776, 14), // "OnHelpBugFixes"
QT_MOC_LITERAL(48, 791, 13), // "OnHelpChanges"
QT_MOC_LITERAL(49, 805, 11) // "OnHelpAbout"

    },
    "CMainFrm\0OnFileNext\0\0OnFilePrev\0"
    "OnFileLoad\0OnFileEditView\0OnFileSave\0"
    "OnFileSaveAs\0GetFileTextEncoding\0"
    "QTextCodec*\0QFile&\0qfileCheck\0OnFileExit\0"
    "OnFindFuncNext\0OnFindFuncPrev\0"
    "OnFindSetText\0OnFindTextNext\0"
    "OnFindTextPrev\0OnFindTextEdited\0"
    "strgNewText\0SetStepParameters\0"
    "OnExecuteStepInto\0OnExecuteStepOutOf\0"
    "OnExecuteStepOver\0OnExecuteRun\0"
    "OnExecuteRunTo\0OnExecuteRunTill\0"
    "OnExecuteHalt\0OnExecuteSlowMotion\0"
    "OnExecuteAnimate\0OnExecuteReset\0"
    "OnOptionsStepOverSpecials\0"
    "OnOptionsModelRegisters\0"
    "OnOptionsErrorOnUninitialized\0"
    "OnOptionsAddedLoopDelay\0"
    "OnOptionsNestedInterrupts\0OnConfigPrefs\0"
    "OnConfigIODevs\0OnWindowsSerialMonitor\0"
    "OnWindowsRestoreAll\0OnWindowsDigitalWaves\0"
    "OnWindowsAnalogWave\0OnVarUpdatesAllowAutoCollapse\0"
    "OnVarUpdatesMinimal\0OnVarUpdatesHighlightChanges\0"
    "OnHelpFull\0OnHelpQuick\0OnHelpBugFixes\0"
    "OnHelpChanges\0OnHelpAbout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CMainFrm[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      44,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  234,    2, 0x0a /* Public */,
       3,    0,  235,    2, 0x0a /* Public */,
       4,    0,  236,    2, 0x0a /* Public */,
       5,    0,  237,    2, 0x0a /* Public */,
       6,    0,  238,    2, 0x0a /* Public */,
       7,    0,  239,    2, 0x0a /* Public */,
       8,    1,  240,    2, 0x0a /* Public */,
      12,    0,  243,    2, 0x0a /* Public */,
      13,    0,  244,    2, 0x0a /* Public */,
      14,    0,  245,    2, 0x0a /* Public */,
      15,    0,  246,    2, 0x0a /* Public */,
      16,    0,  247,    2, 0x0a /* Public */,
      17,    0,  248,    2, 0x0a /* Public */,
      18,    1,  249,    2, 0x0a /* Public */,
      20,    0,  252,    2, 0x0a /* Public */,
      21,    0,  253,    2, 0x0a /* Public */,
      22,    0,  254,    2, 0x0a /* Public */,
      23,    0,  255,    2, 0x0a /* Public */,
      24,    0,  256,    2, 0x0a /* Public */,
      25,    0,  257,    2, 0x0a /* Public */,
      26,    0,  258,    2, 0x0a /* Public */,
      27,    0,  259,    2, 0x0a /* Public */,
      28,    0,  260,    2, 0x0a /* Public */,
      29,    0,  261,    2, 0x0a /* Public */,
      30,    0,  262,    2, 0x0a /* Public */,
      31,    0,  263,    2, 0x0a /* Public */,
      32,    0,  264,    2, 0x0a /* Public */,
      33,    0,  265,    2, 0x0a /* Public */,
      34,    0,  266,    2, 0x0a /* Public */,
      35,    0,  267,    2, 0x0a /* Public */,
      36,    0,  268,    2, 0x0a /* Public */,
      37,    0,  269,    2, 0x0a /* Public */,
      38,    0,  270,    2, 0x0a /* Public */,
      39,    0,  271,    2, 0x0a /* Public */,
      40,    0,  272,    2, 0x0a /* Public */,
      41,    0,  273,    2, 0x0a /* Public */,
      42,    0,  274,    2, 0x0a /* Public */,
      43,    0,  275,    2, 0x0a /* Public */,
      44,    0,  276,    2, 0x0a /* Public */,
      45,    0,  277,    2, 0x0a /* Public */,
      46,    0,  278,    2, 0x0a /* Public */,
      47,    0,  279,    2, 0x0a /* Public */,
      48,    0,  280,    2, 0x0a /* Public */,
      49,    0,  281,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 9, 0x80000000 | 10,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void CMainFrm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        CMainFrm *_t = static_cast<CMainFrm *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->OnFileNext(); break;
        case 1: _t->OnFilePrev(); break;
        case 2: _t->OnFileLoad(); break;
        case 3: _t->OnFileEditView(); break;
        case 4: _t->OnFileSave(); break;
        case 5: _t->OnFileSaveAs(); break;
        case 6: { QTextCodec* _r = _t->GetFileTextEncoding((*reinterpret_cast< QFile(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QTextCodec**>(_a[0]) = _r; }  break;
        case 7: _t->OnFileExit(); break;
        case 8: _t->OnFindFuncNext(); break;
        case 9: _t->OnFindFuncPrev(); break;
        case 10: _t->OnFindSetText(); break;
        case 11: _t->OnFindTextNext(); break;
        case 12: _t->OnFindTextPrev(); break;
        case 13: _t->OnFindTextEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 14: _t->SetStepParameters(); break;
        case 15: _t->OnExecuteStepInto(); break;
        case 16: _t->OnExecuteStepOutOf(); break;
        case 17: _t->OnExecuteStepOver(); break;
        case 18: _t->OnExecuteRun(); break;
        case 19: _t->OnExecuteRunTo(); break;
        case 20: _t->OnExecuteRunTill(); break;
        case 21: _t->OnExecuteHalt(); break;
        case 22: _t->OnExecuteSlowMotion(); break;
        case 23: _t->OnExecuteAnimate(); break;
        case 24: _t->OnExecuteReset(); break;
        case 25: _t->OnOptionsStepOverSpecials(); break;
        case 26: _t->OnOptionsModelRegisters(); break;
        case 27: _t->OnOptionsErrorOnUninitialized(); break;
        case 28: _t->OnOptionsAddedLoopDelay(); break;
        case 29: _t->OnOptionsNestedInterrupts(); break;
        case 30: _t->OnConfigPrefs(); break;
        case 31: _t->OnConfigIODevs(); break;
        case 32: _t->OnWindowsSerialMonitor(); break;
        case 33: _t->OnWindowsRestoreAll(); break;
        case 34: _t->OnWindowsDigitalWaves(); break;
        case 35: _t->OnWindowsAnalogWave(); break;
        case 36: _t->OnVarUpdatesAllowAutoCollapse(); break;
        case 37: _t->OnVarUpdatesMinimal(); break;
        case 38: _t->OnVarUpdatesHighlightChanges(); break;
        case 39: _t->OnHelpFull(); break;
        case 40: _t->OnHelpQuick(); break;
        case 41: _t->OnHelpBugFixes(); break;
        case 42: _t->OnHelpChanges(); break;
        case 43: _t->OnHelpAbout(); break;
        default: ;
        }
    }
}

const QMetaObject CMainFrm::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_CMainFrm.data,
      qt_meta_data_CMainFrm,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *CMainFrm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CMainFrm::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_CMainFrm.stringdata0))
        return static_cast<void*>(const_cast< CMainFrm*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int CMainFrm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 44)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 44;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 44)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 44;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
